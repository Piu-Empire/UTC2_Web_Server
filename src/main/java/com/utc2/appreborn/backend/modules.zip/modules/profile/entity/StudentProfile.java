package com.utc2.appreborn.backend.modules.profile.entity;

import com.utc2.appreborn.backend.modules.auth.entity.User;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "student_profile")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentProfile {

    @Id
    @Column(name = "user_id")
    private Long userId;

    @OneToOne
    @MapsId
    @JoinColumn(name = "user_id")
    private User user;

    @Column(name = "student_code", unique = true)
    private String studentCode;

    @Column(name = "faculty")
    private String faculty;

    @Column(name = "major")
    private String major;

    @Column(name = "academic_year")
    private String academicYear;

    @Column(name = "class_name")
    private String className;

    @Column(name = "status")
    private String status;

    @Column(name = "advisor_id")
    private Long advisorId;

    @Column(name = "student_card_url", columnDefinition = "TEXT")
    private String studentCardUrl;   // ← thêm mới: ảnh thẻ sinh viên
}